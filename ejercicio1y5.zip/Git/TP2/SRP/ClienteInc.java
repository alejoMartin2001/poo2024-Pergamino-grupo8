//El primero SRP consiste en que cada clase debe tener una sola responsabilidad.
package SRP;
//SRP incumplimiento
public class ClienteInc{
    private String nombre;
    private String apellido;
    private double edad;
    private String cuil;
    private double dni;
    private double nroCliente;
    
    public ClienteInc(String nombre, String apellido, double edad, String cuil, double dni, double nroCliente) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cuil = cuil;
        this.dni = dni;
        this.nroCliente = nroCliente;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public double getEdad() {
        return edad;
    }
    public void setEdad(double edad) {
        this.edad = edad;
    }
    public String getCuil() {
        return cuil;
    }
    public void setCuil(String cuil) {
        this.cuil = cuil;
    }
    public double getDni() {
        return dni;
    }
    public void setDni(double dni) {
        this.dni = dni;
    }
    public double getNroCliente() {
        return nroCliente;
    }
    public void setNroCliente(double nroCliente) {
        this.nroCliente = nroCliente;
    }
}
