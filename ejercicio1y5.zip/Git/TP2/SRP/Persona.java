package SRP;
//parte del SRP cumplimiento
public class Persona {
    private String nombre;
    private String apellido;
    private double edad;
    private String cuil;
    private double dni;
    
    public Persona(String nombre, String apellido, double edad, String cuil, double dni) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.cuil = cuil;
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public double getEdad() {
        return edad;
    }

    public void setEdad(double edad) {
        this.edad = edad;
    }

    public String getCuil() {
        return cuil;
    }

    public void setCuil(String cuil) {
        this.cuil = cuil;
    }

    public double getDni() {
        return dni;
    }

    public void setDni(double dni) {
        this.dni = dni;
    }
}
