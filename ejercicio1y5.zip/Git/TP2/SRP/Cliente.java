package SRP;
//SRP cumplimiento
public class Cliente extends Persona{
    private double nroCliente;

    public Cliente(String nombre, String apellido, double edad, String cuil, double dni,double nroCliente){
        super(nombre,apellido,edad,cuil,dni);
        this.nroCliente = nroCliente;
    }

    public double getNroCliente() {
        return nroCliente;
    }

    public void setNroCliente(double nroCliente) {
        this.nroCliente = nroCliente;
    }
    
}
