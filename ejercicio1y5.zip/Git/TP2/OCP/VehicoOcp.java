package OCP;
//cumplimiento de OCP
public interface VehicoOcp {
    public void encender();
    public void acelerar();
    public void desacelerar();
    public void frenar();
}
