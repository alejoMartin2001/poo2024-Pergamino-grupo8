package OCP;
//cumplimiento de OCP
public class Moto implements VehicoOcp{
    private String marca;
    private String modelo;
    private boolean encendido;
    private double velocidad;
    
    public Moto(String marca, String modelo, boolean encendido, double velocidad) {
        this.marca = marca;
        this.modelo = modelo;
        this.encendido = encendido;
        this.velocidad = velocidad;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }

    public double getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(double velocidad) {
        this.velocidad = velocidad;
    }

    public void encender(){
        this.setEncendido(true);
    }

    public void incrementarVelocidad(){
        this.setVelocidad(1+getVelocidad());
    }

    public void decrementarVelocidad(){
        this.setVelocidad(1-getVelocidad());
    }

    public void acelerar(){
        this.incrementarVelocidad();
    }
    public void desacelerar(){
        this.decrementarVelocidad();
    }
    public void frenar(){
        this.setVelocidad(0);
    }
}
