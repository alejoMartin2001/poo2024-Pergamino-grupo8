//el principio OCP basicamente dice que una clase debe poder extender su funcionalidad, 
//sin modificarse osea a través de herencia.
package OCP;
//incumplimiento de OCP
public class Vehiculo {
    private String vehiculo;
    private String color;
    private String marca;
    private String modelo;
    private double velocidad;
    private boolean encendido;
    
    public Vehiculo() {
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(double velocidad) {
        this.velocidad = velocidad;
    }

    public String getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(String vehiculo) {
        this.vehiculo = vehiculo;
    }

    public boolean isEncendido() {
        return encendido;
    }

    public void setEncendido(boolean encendido) {
        this.encendido = encendido;
    }
    //a medida que haya distintos tipos de vehiculos tengo que alterar la funcionalidad de 
    //clase, ERROR.
    public void acelerar(){
        if(getVehiculo() == "auto"){
            System.out.println("Auto acelerando" + getVelocidad());
        }
        if(getVehiculo() == "moto"){
            System.out.println("Moto acelerando" + getVelocidad());
        }
        if(getVehiculo() == "barco"){
            System.out.println("Barco acelerando" + getVelocidad());
        }
        if(getVehiculo() == "avión"){
            System.out.println("Avión acelerando" + getVelocidad());
        }
    }
    

}